# login/init.py

import pymysql

pymysql.install_as_MySQLdb()